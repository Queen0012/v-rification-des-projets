import streamlit as st
import pandas as pd
import mysql.connector

# Database connection
conn = mysql.connector.connect(
    host='localhost',
    port=3306,
    user='root', 
    password='1234', 
    database='pfe'
)
c = conn.cursor()

# Streamlit app
st.set_page_config(
    page_icon="🎓",
    page_title="Gestion des PFE",
    layout="wide"
)

st.title("Gestion des PFE")

# Define the columns for the layout
col1, col2 = st.columns([1, 3]) 

# Input fields in the left column
with col1:
    id = st.text_input("ID", key="ID")
    pfe = st.text_input("PFE", key="pfe")
    filiere = st.selectbox("Filière", ("telecoms", "informatique", "managment"), key="filiere")
    annee = st.text_input("Année", key="annee")
    etudiant = st.text_input("Étudiant", key="etudiant")
    encadreur = st.text_input("Encadreur", key="encadreur")
    note = st.number_input("Note", min_value=0.0, max_value=20.0, step=0.1, key="note")
    centre = st.selectbox("Centre", ("Sarh", "N'djamena", "Amdjarass"), key="centre")

    # File upload
    uploaded_file = st.file_uploader("Télécharger un document", type=['pdf', 'docx', 'txt'], key="observation")

    # Buttons
    save_button = st.button("Enregistrer", key="save")
    modify_button = st.button("Modifier", key="modify")
    delete_button = st.button("Supprimer", key="delete")

# Function to save data to the database
def save_data():
    if all([id, pfe, filiere, annee, etudiant, encadreur, note, centre]):
        # Check if ID already exists
        c.execute("SELECT * FROM listes WHERE ID = %s", (id,))
        existing_id = c.fetchone()
        if existing_id:
            st.error("Un PFE avec cet ID existe déjà.")
        else:
            # Convert uploaded file to bytes
            if uploaded_file:
                file_bytes = uploaded_file.read()

                # Insert data into the database
                c.execute("""
                    INSERT INTO listes (ID, pfe, filiere, annee, etudiant, encadreur, note, centre, observation)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (id, pfe, filiere, annee, etudiant, encadreur, note, centre, file_bytes))
                conn.commit()
                st.success("PFE enregistré avec succès.")
            else:
                st.error("Veuillez télécharger un document.")
    else:
        st.error("Veuillez remplir tous les champs.")

# Function to modify data in the database
def modify_data():
    if all([id, pfe, filiere, annee, etudiant, encadreur, note, centre]):
        # Convert uploaded file to bytes
        if uploaded_file:
            file_bytes = uploaded_file.read()

            c.execute("""
                UPDATE listes 
                SET pfe=%s, filiere=%s, annee=%s, etudiant=%s, encadreur=%s, note=%s, centre=%s, observation=%s
                WHERE id=%s
            """, (pfe, filiere, annee, etudiant, encadreur, note, centre, file_bytes, id))
            conn.commit()
            st.success("PFE modifié avec succès.")
        else:
            st.error("Veuillez télécharger un document.")
    else:
        st.error("Veuillez remplir tous les champs pour la modification")

# Function to delete data from the database
def delete_data():
    if id:
        c.execute("DELETE FROM listes WHERE id=%s", (id,))
        conn.commit()
        st.success("PFE supprimé avec succès.")
    else:
        st.error("Veuillez sélectionner un ID à supprimer.")

# Display the data in a table
def display_table():
    c.execute("SELECT * FROM listes")
    data = c.fetchall()
    df = pd.DataFrame(data, columns=['ID', 'PFE', 'Filière', 'Année', 'Étudiant', 'Encadreur', 'Note', 'Centre', 'Observation']) 
    with col2: 
        st.dataframe(df)

# Event handling
if save_button:
    save_data()

if modify_button:
    modify_data()

if delete_button:
    delete_data()

# Display table
display_table()

# Close connection
conn.close()