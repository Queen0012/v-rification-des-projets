import streamlit as st
import mysql.connector
import pandas as pd
import base64

# Connexion à la base de données MySQL locale
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="1234",
    database="pfe"
)
cursor = conn.cursor()

# Streamlit app
st.set_page_config(
    page_icon="🎓",
    page_title="Vérification des PFE",
    layout="wide"
)

# Fonction pour chercher la similarité dans la colonne PFE
def chercher_similarite(theme):
    query = "SELECT ID, pfe, annee, filiere, etudiant, encadreur, note, centre, observation FROM listes WHERE pfe LIKE %s" 
    cursor.execute(query, ('%' + theme + '%',))
    resultats = cursor.fetchall()

    # Convertir les résultats en DataFrame
    df = pd.DataFrame(resultats, columns=['ID', 'pfe', 'annee', 'filiere', 'etudiant', 'encadreur', 'note', 'centre', 'observation'])
    return df

# Fonction pour convertir un fichier binaire en lien de téléchargement
def get_download_link(data, filename, extension):
    b64 = base64.b64encode(data).decode()
    href = f'<a href="data:application/{extension};base64,{b64}" download="{filename}.{extension}">Télécharger le document</a>'
    return href

# Fonction pour afficher les données dans un tableau avec liens
def display_table(df):
    # Create DataFrame and modify observation column to include links
    df['observation'] = df['observation'].apply(lambda x: get_download_link(x, 'document', 'bin')) # Keep extension as 'pdf'
    st.write(df.to_html(escape=False), unsafe_allow_html=True)

# Interface utilisateur Streamlit
st.title("Recherche de similarité ")
theme = st.text_input("Entrez votre thème ou le mot-clé:")

if st.button("Rechercher"):
    if theme:
        df_resultat = chercher_similarite(theme)
        # st.write(df_resultat) # Remove this line to hide the first table
        display_table(df_resultat) 
    else:
        st.write("Veuillez entrer un thème ou le mot-clé.")

# Fermer la connexion à la base de données
conn.close()
